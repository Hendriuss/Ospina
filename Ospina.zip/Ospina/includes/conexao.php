<?php
// Define o fuso horário para evitar problemas de tempo no servidor/DB
date_default_timezone_set('America/Sao_Paulo');

class Database {
    private $conexao; // Melhor usar private para encapsular a conexão
    
    // Configurações padrão para o XAMPP
    public function __construct(
        $host = "localhost",
        $usuario = "root",
        $senha = "",
        $base = "Ospina" // Certifique-se que este é o nome CORRETO do seu banco de dados
    ){
        // Estabelece a conexão usando MySQLi
        $this->conexao = new mysqli($host, $usuario, $senha, $base);
        
        // Verifica se houve erro na conexão (Ex: credenciais erradas ou DB inativo)
        if ($this->conexao->connect_error) {
            // Se houver erro, exibe a mensagem de erro e interrompe o script
            die("Erro na conexão com o Banco de Dados: " . $this->conexao->connect_error);
        }
        
        // Define o charset para evitar problemas com acentuação
        $this->conexao->set_charset("utf8mb4");
    }

    /**
     * Prepara e executa uma consulta, fazendo o bind dos parâmetros.
     * * @param string $sql A consulta SQL.
     * @param string|null $tipos String de tipos (ex: "s", "i", "d").
     * @param mixed ...$parametros Os valores a serem vinculados.
     * @return \mysqli_stmt O objeto de statement executado.
     */
    public function prepareAndExecute($sql, $tipos = null, ...$parametros) {
        $stmt = $this->conexao->prepare($sql);
        
        if (!$stmt) {
            // Se a preparação falhar (ex: erro de sintaxe SQL), interrompe
            die("Erro ao preparar a consulta: " . $this->conexao->error);
        }

        // Adiciona a verificação: só tenta fazer bind se houver tipos E parâmetros
        if ($tipos !== null && count($parametros) > 0) {
            // Faz o bind dos tipos e dos parâmetros
            $stmt->bind_param($tipos, ...$parametros);
        }

        $stmt->execute();
        return $stmt;
    }

    public function close() {
        if ($this->conexao) {
            $this->conexao->close();
        }
    }
}
?>