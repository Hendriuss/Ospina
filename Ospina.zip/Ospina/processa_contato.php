<?php
// Certifique-se de que o formulário foi enviado via método POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Pega os dados do formulário de forma segura
    $nome    = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);
    $email   = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $assunto = filter_input(INPUT_POST, 'assunto', FILTER_SANITIZE_STRING);
    $mensagem = filter_input(INPUT_POST, 'mensagem', FILTER_SANITIZE_STRING);

    // Validação básica dos campos
    if (empty($nome) || empty($email) || empty($assunto) || empty($mensagem)) {
        header("Location: contato.php?status=error");
        exit;
    }

    // Configurações do email para onde a mensagem será enviada
    $email_destino = "seu_email@dominio.com"; // 🚨 Troque por seu email real
    $assunto_email = "Mensagem do Formulário de Contato: " . $assunto;
    $headers = "From: " . $email . "\r\n";
    $headers .= "Reply-To: " . $email . "\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

    $corpo_email = "Nome: " . $nome . "\n";
    $corpo_email .= "Email: " . $email . "\n\n";
    $corpo_email .= "Mensagem:\n" . $mensagem;

    // Tenta enviar o email
    if (mail($email_destino, $assunto_email, $corpo_email, $headers)) {
        // Redireciona para a página de contato com mensagem de sucesso
        header("Location: contato.php?status=success");
        exit;
    } else {
        // Redireciona para a página de contato com mensagem de erro
        header("Location: contato.php?status=error");
        exit;
    }
} else {
    // Se a página for acessada diretamente sem o formulário, redireciona
    header("Location: contato.php");
    exit;
}
?>