<?php
// 1. Configuração Inicial e Inclusão de Dados
session_start();
include_once("produtos_data.php"); 
include_once("includes/menu.php"); 

// 2. Lógica para obter e verificar o produto
$produto = null;
$produto_id = isset($_GET['id']) ? $_GET['id'] : null;

if ($produto_id !== null && array_key_exists($produto_id, $produtos)) {
    $produto = $produtos[$produto_id];
} else {
    header("Location: index.php");
    exit();
}

$page_title = $produto['nome'];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?> | Essência Pura</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    
    <style>
        :root {
            --primary-color: #7ca982;
            --dark-blue: #0056b3;
            --lime-green: #32CD32;
        }

        body {
            background-color: #f4f7f6;
            padding-top: 100px;
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
        }

        nav.navbar {
            background-color: rgba(124, 169, 130, 0.95) !important;
            backdrop-filter: blur(10px);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .produto-container {
            background: #fff;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.05);
        }

        .img-produto-wrapper {
            padding: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #fff;
        }

        .img-produto-wrapper img {
            max-height: 550px;
            width: auto;
            border-radius: 15px;
            transition: transform 0.3s ease;
        }

        .img-produto-wrapper img:hover {
            transform: scale(1.02);
        }

        .detalhes-card {
            padding: 40px;
            height: 100%;
        }

        .badge-estoque {
            background-color: #e8f5e9;
            color: #2e7d32;
            padding: 5px 12px;
            border-radius: 50px;
            font-size: 0.85rem;
            font-weight: 600;
        }

        .preco-tag {
            font-size: 2.5rem;
            font-weight: 800;
            color: #2c3e50;
            letter-spacing: -1px;
        }

        /* Botões Personalizados */
        .btn-add-carrinho {
            background-color: var(--dark-blue);
            color: white;
            border: none;
            padding: 15px;
            transition: all 0.3s;
        }

        .btn-add-carrinho:hover {
            background-color: #004494;
            transform: translateY(-2px);
            color: white;
        }

        .btn-compre-agora {
            background-color: var(--lime-green);
            color: white;
            border: none;
            padding: 15px;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .btn-compre-agora:hover {
            background-color: #28a745;
            transform: translateY(-2px);
            color: white;
        }

        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(124, 169, 130, 0.25);
        }
    </style>
</head>
<body>

<div class="container mt-4">
    <a href="index.php#produtos" class="btn btn-outline-secondary px-4 shadow-sm">
        <i class="bi bi-arrow-left me-2"></i> Voltar aos Produtos
    </a>
</div>

    <div class="row produto-container g-0">
        <div class="col-md-6 img-produto-wrapper">
            <img src="<?= htmlspecialchars($produto['imagem']) ?>" class="img-fluid" alt="<?= htmlspecialchars($produto['nome']) ?>">
        </div>

        <div class="col-md-6">
            <div class="detalhes-card">
                <span class="badge-estoque mb-3 d-inline-block">
                    <i class="bi bi-check-circle-fill me-1"></i> Em estoque
                </span>
                
                <h1 class="display-5 fw-bold mb-2"><?= htmlspecialchars($produto['nome']) ?></h1>
                <p class="text-muted mb-4 small">SKU: EP-<?= str_pad($produto_id, 4, '0', STR_PAD_LEFT) ?> | Categoria: Perfumaria Premium</p>

                <div class="preco-tag mb-4">
                    <span class="fs-4 fw-normal">R$</span> <?= number_format($produto['preco'], 2, ',', '.') ?>
                </div>

                <div class="mb-4">
                    <h6 class="fw-bold text-uppercase small">Descrição</h6>
                    <p class="text-secondary">
                        <?= htmlspecialchars($produto['descricao'] ?? 'Fragrância exclusiva com notas florais e amadeiradas, garantindo fixação duradoura e elegante.') ?>
                    </p>
                </div>

                <div class="row mb-4 text-center g-2">
                    <div class="col-4">
                        <div class="p-2 border rounded shadow-sm">
                            <small class="text-muted d-block">Tipo</small>
                            <strong>EDP</strong>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="p-2 border rounded shadow-sm">
                            <small class="text-muted d-block">Volume</small>
                            <strong>100ml</strong>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="p-2 border rounded shadow-sm">
                            <small class="text-muted d-block">Fixação</small>
                            <strong>Longa</strong>
                        </div>
                    </div>
                </div>

                <form action="carrinho.php" method="GET">
                    <input type="hidden" name="action" value="add">
                    <input type="hidden" name="id" value="<?= htmlspecialchars($produto_id) ?>">
                    
                    <div class="row g-3 mb-4">
                        <div class="col-4">
                            <label class="form-label small fw-bold">Qtd:</label>
                            <input type="number" name="quantity" class="form-control form-control-lg text-center" value="1" min="1">
                        </div>
                        <div class="col-8">
                            <label class="form-label small fw-bold">CEP:</label>
                            <div class="input-group input-group-lg">
                                <input type="text" id="cep" class="form-control fs-6" placeholder="00000-000" maxlength="9" onkeyup="formatarCEP(this)">
                                <button class="btn btn-outline-secondary" type="button" onclick="consultarCEP()"><i class="bi bi-truck"></i></button>
                            </div>
                        </div>
                    </div>

                    <div id="resultado-endereco" class="mb-2 small"></div>
                    <div id="resultado-frete" class="mb-4 small fw-bold"></div>

                    <div class="d-grid gap-3">
                        <button type="submit" class="btn btn-lg btn-add-carrinho rounded-3">
                            <i class="bi bi-cart-plus me-2"></i> Adicionar ao Carrinho
                        </button>
                        <button type="submit" class="btn btn-lg btn-compre-agora rounded-3" formaction="carrinho.php?action=add&checkout=true">
                            <i class="bi bi-lightning-charge me-2"></i> Compre Agora
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<footer class="bg-dark text-white py-5">
    <div class="container text-center">
        <p class="mb-0">© 2026 Essência Pura. Todos os direitos reservados.</p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
    function formatarCEP(input) {
        let value = input.value.replace(/\D/g, '');
        if (value.length > 5) {
            value = value.substring(0, 5) + '-' + value.substring(5, 8);
        }
        input.value = value;
    }

    function consultarCEP() {
        const cep = document.getElementById('cep').value.replace(/\D/g, '');
        const resEnd = document.getElementById('resultado-endereco');
        const resFre = document.getElementById('resultado-frete');
        
        if (cep.length !== 8) {
            resEnd.innerHTML = '<span class="text-danger">CEP inválido.</span>';
            return;
        }

        resEnd.innerHTML = '<div class="spinner-border spinner-border-sm text-success" role="status"></div> Consultando...';

        fetch(`https://viacep.com.br/ws/${cep}/json/`)
            .then(r => r.json())
            .then(data => {
                if (data.erro) {
                    resEnd.innerHTML = '<span class="text-danger">Não encontrado.</span>';
                } else {
                    resEnd.innerHTML = `<i class="bi bi-geo-alt"></i> ${data.localidade}, ${data.uf}`;
                    resFre.innerHTML = `<span class="text-success"><i class="bi bi-truck"></i> Frete: R$ 15,90 - Entrega em 4 dias</span>`;
                }
            });
    }
</script>
</body>
</html>