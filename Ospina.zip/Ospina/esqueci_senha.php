<?php
session_start();
include_once "includes/conexao.php"; 

$mensagem = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // A lógica de envio de email e token (que discutimos anteriormente) entraria aqui.
    // Por enquanto, vamos apenas simular a mensagem de sucesso:
    
    $email = trim($_POST['email']);
    
    // Simulação: Se o e-mail estiver cadastrado (LÓGICA REAL DEVE SER IMPLEMENTADA)
    if (!empty($email)) {
        // Lógica para: 1. Gerar token. 2. Salvar token no BD. 3. Enviar e-mail.
        
        $mensagem = "Se o e-mail estiver cadastrado, você receberá um link para redefinição de senha em breve. Por favor, verifique sua caixa de entrada e spam.";
    } else {
        $mensagem = "Por favor, insira um endereço de e-mail válido.";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Recuperar Senha - Essência Pura</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<style>
    /* * ESTILOS COPIADOS DO SEU ARQUIVO login.php 
    * para manter a consistência visual.
    */
    body {
        background-color: #f5f0e6;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
    }

    .login-container {
        width: 100%;
        max-width: 400px;
        padding: 40px;
        border-radius: 10px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        background-color: #fff;
        text-align: center;
        position: relative;
    }

    .header-logo {
        font-family: serif;
        color: #7CA982;
        margin-bottom: 25px;
        font-size: 2rem;
        font-weight: bold;
    }

    .btn-principal {
        background-color: #7CA982;
        border-color: #7CA982;
        color: white;
        transition: background-color 0.3s;
    }

    .btn-principal:hover {
        background-color: #5d8463;
        border-color: #5d8463;
    }
    
    /* Adaptado para a mensagem de status */
    .alert-status {
        margin-bottom: 20px;
        padding: 12px 25px;
        border-radius: 8px;
        text-align: center;
    }
</style>
</head>
<body>

<div class="login-container">
    <div class="header-logo">
        <i class="bi bi-key-fill me-2"></i> Essência Pura
    </div>

    <h5 class="mb-4">Recuperação de Senha</h5>

    <?php if ($mensagem): ?>
        <div class="alert alert-info alert-status">
            <?= $mensagem ?>
        </div>
        
        <a href="login.php" class="text-secondary d-block mt-3">Voltar para o Login</a>

    <?php else: ?>
        <p class="mb-4 text-muted">Insira seu e-mail para que possamos enviar um link de redefinição.</p>
    
        <form method="POST">
            <div class="mb-4 text-start">
                <label for="email" class="form-label">E-mail de Cadastro</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
    
            <div class="d-grid gap-2 mb-3">
                <button type="submit" class="btn btn-principal btn-lg">Enviar Link</button>
            </div>
            
            <a href="login.php" class="text-secondary d-block">Lembrei minha senha! Voltar para o Login</a>
        </form>

    <?php endif; ?>
    
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>