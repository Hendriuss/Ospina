USE loja_minecraft;

-- Desativa verificação de chaves para poder apagar em qualquer ordem
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS vendas;
DROP TABLE IF EXISTS produtos;
DROP TABLE IF EXISTS categorias;
SET FOREIGN_KEY_CHECKS = 1;

-- 1. Categorias
CREATE TABLE categorias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL
);

-- 2. Produtos (Agora com preco_antigo incluído corretamente)
CREATE TABLE produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    categoria_id INT,
    nome VARCHAR(100) NOT NULL,
    descricao TEXT,
    preco DECIMAL(10, 2) NOT NULL,
    preco_antigo DECIMAL(10, 2), 
    comando_rcon VARCHAR(255) NOT NULL,
    imagem_url VARCHAR(255),
    estoque INT DEFAULT 0,
    FOREIGN KEY (categoria_id) REFERENCES categorias(id) ON DELETE SET NULL
);

-- 3. Vendas
CREATE TABLE vendas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transacao_id VARCHAR(100) UNIQUE,
    player_nickname VARCHAR(16) NOT NULL,
    produto_id INT,
    valor_pago DECIMAL(10, 2),
    status_pagamento ENUM('pendente', 'aprovado', 'cancelado') DEFAULT 'pendente',
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    entregue TINYINT(1) DEFAULT 0,
    FOREIGN KEY (produto_id) REFERENCES produtos(id) ON DELETE SET NULL
);

-- Inserindo um produto de teste para validar o campo novo
INSERT INTO categorias (nome) VALUES ('Contas');
INSERT INTO produtos (categoria_id, nome, preco, preco_antigo, comando_rcon, estoque) 
VALUES (1, 'Minecraft FA', 70.00, 90.00, 'say {player} ativou!', 10);

CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario VARCHAR(50) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL
);

-- O utilizador será 'admin' e a senhaloja_minecraft será 'admin123' (encriptada para segurança)
INSERT INTO usuarios (usuario, senha) VALUES ('admin', '$2y$10$89Wpbe24tN.tP6fI0C8HBeV.o5yE5E8j7p2H8G.vXhG8Z9Xy0W5K.');