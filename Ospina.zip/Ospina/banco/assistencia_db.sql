-- 1. Criar o Banco de Dados
CREATE DATABASE IF NOT EXISTS fahim_assistencia;
USE fahim_assistencia;

-- 2. Tabela de Clientes
CREATE TABLE IF NOT EXISTS clientes (
    id_cliente INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    cpf_cnpj VARCHAR(20) UNIQUE,
    telefone VARCHAR(20) NOT NULL,
    email VARCHAR(100),
    endereco TEXT,
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 3. Tabela de Produtos (Com suporte a foto e alertas de estoque)
CREATE TABLE IF NOT EXISTS produtos (
    id_produto INT PRIMARY KEY AUTO_INCREMENT,
    nome_produto VARCHAR(100) NOT NULL,
    marca VARCHAR(50),
    preco_custo DECIMAL(10,2) DEFAULT 0.00,
    preco_venda DECIMAL(10,2) NOT NULL,
    estoque_atual INT DEFAULT 0,
    estoque_minimo INT DEFAULT 2,
    imagem VARCHAR(255) DEFAULT 'default.png',
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 4. Tabela de Usuários (Para o Login do sistema)
CREATE TABLE IF NOT EXISTS usuarios (
    id_usuario INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    login VARCHAR(50) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL, -- Aqui vai a senha criptografada
    nivel ENUM('admin', 'tecnico') DEFAULT 'admin'
) ENGINE=InnoDB;

-- 5. Tabela de Ordens de Serviço (O.S.)
CREATE TABLE IF NOT EXISTS ordens_servico (
    id_os INT PRIMARY KEY AUTO_INCREMENT,
    id_cliente INT NOT NULL,
    aparelho VARCHAR(100) NOT NULL,
    serie_imei VARCHAR(50),
    defeito_relatado TEXT,
    laudo_tecnico TEXT,
    status ENUM('Aberto', 'Em Análise', 'Aguardando Peça', 'Pronto', 'Entregue', 'Cancelado') DEFAULT 'Aberto',
    valor_servico DECIMAL(10,2) DEFAULT 0.00,
    valor_pecas DECIMAL(10,2) DEFAULT 0.00,
    data_entrada TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_saida DATETIME,
    FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 6. Tabela de Vendas
CREATE TABLE IF NOT EXISTS vendas (
    id_venda INT PRIMARY KEY AUTO_INCREMENT,
    id_cliente INT NULL,
    data_venda TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    total_venda DECIMAL(10,2),
    metodo_pagamento VARCHAR(50),
    FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente)
) ENGINE=InnoDB;

-- 7. Itens da Venda (Relacionamento Muitos-para-Muitos)
CREATE TABLE IF NOT EXISTS itens_venda (
    id_item INT PRIMARY KEY AUTO_INCREMENT,
    id_venda INT,
    id_produto INT,
    quantidade INT,
    preco_unitario DECIMAL(10,2),
    FOREIGN KEY (id_venda) REFERENCES vendas(id_venda) ON DELETE CASCADE,
    FOREIGN KEY (id_produto) REFERENCES produtos(id_produto)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- INSERÇÃO DE DADOS INICIAIS (Para teste)
-- ---------------------------------------------------------

-- Inserindo um usuário administrativo (Senha padrão: admin123)
-- Nota: Em produção, usaremos password_hash. Para este teste o hash abaixo é 'admin123'
INSERT INTO usuarios (nome, login, senha) VALUES 
('Fahim Admin', 'admin', '$2y$10$7raff6S.A.I579xnvK.O7.BvY/fGv7XW5wR0P0HjX7H.YnJdD8Z6G');

-- Inserindo alguns produtos para a sua vitrine
INSERT INTO produtos (nome_produto, marca, preco_venda, estoque_atual, estoque_minimo, imagem) VALUES 
('Capinha Silicone iPhone 13', 'Apple', 59.90, 15, 3, 'default.png'),
('Película Cerâmica 9D S23', 'Samsung', 35.00, 20, 5, 'default.png'),
('Carregador Turbo 20W', 'Xiaomi', 89.00, 8, 2, 'default.png'),
('Cabo Lightning 1m', 'Apple', 45.00, 12, 4, 'default.png');