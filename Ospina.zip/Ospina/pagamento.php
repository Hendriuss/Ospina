<?php
session_start();
include 'produtos_data.php';
include_once("includes/menu.php");

if (empty($_SESSION['carrinho'])) {
    header("Location: carrinho.php");
    exit;
}

$total_carrinho = 0;
foreach ($_SESSION['carrinho'] as $id_produto) {
    if (isset($produtos[$id_produto])) {
        $total_carrinho += $produtos[$id_produto]['preco'];
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagamento | Essência Pura</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root { --primary-green: #7ca982; --dark-green: #5d8463; }
        
        body { 
            background-color: #f4f7f6; 
            padding-top: 100px;
            font-family: 'Inter', sans-serif;
        }

        .summary-card {
            background: white;
            border: none;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.05);
        }

        .payment-card {
            border: 2px solid transparent;
            border-radius: 20px;
            transition: all 0.3s ease;
            background: white;
            cursor: pointer;
            height: 100%;
            text-decoration: none;
            display: block;
        }

        .payment-card:hover {
            transform: translateY(-8px);
            border-color: var(--primary-green);
            box-shadow: 0 15px 35px rgba(124, 169, 130, 0.1);
        }

        .payment-card i {
            font-size: 3rem;
            margin-bottom: 1.5rem;
            display: block;
            transition: 0.3s;
        }

        .payment-card:hover i {
            transform: scale(1.1);
        }

        .text-pix { color: #32bcad; }
        .text-card { color: var(--primary-green); }
        .text-boleto { color: #f39c12; }

        .btn-back {
            color: #888;
            text-decoration: none;
            font-weight: 500;
            transition: 0.3s;
        }

        .btn-back:hover { color: var(--dark-green); }
    </style>
</head>
<body>

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            
            <div class="d-flex justify-content-between align-items-center mb-4">
                <a href="carrinho.php" class="btn-back"><i class="bi bi-arrow-left"></i> Voltar ao carrinho</a>
                <h2 class="fw-bold m-0">Pagamento</h2>
            </div>

            <div class="card summary-card p-4 mb-5 text-center">
                <span class="text-muted text-uppercase small fw-bold tracking-wider">Total a pagar</span>
                <h1 class="display-5 fw-bold text-dark m-0">R$ <?= number_format($total_carrinho, 2, ',', '.') ?></h1>
            </div>

            <h5 class="text-center text-muted mb-4">Selecione como deseja pagar:</h5>

            <div class="row g-4">
                <div class="col-md-4">
                    <a href="finalizar_compra.php?metodo=pix" class="payment-card p-4 text-center">
                        <i class="bi bi-qr-code-scan text-pix"></i>
                        <h4 class="fw-bold text-dark">PIX</h4>
                        <p class="text-muted small">Aprovação imediata e 100% segura.</p>
                        <span class="badge bg-light text-success rounded-pill px-3 py-2">Recomendado</span>
                    </a>
                </div>

                <div class="col-md-4">
                    <a href="finalizar_compra.php?metodo=cartao" class="payment-card p-4 text-center">
                        <i class="bi bi-credit-card-2-back text-card"></i>
                        <h4 class="fw-bold text-dark">Cartão</h4>
                        <p class="text-muted small">Parcele em até 12x sem juros no cartão.</p>
                    </a>
                </div>

                <div class="col-md-4">
                    <a href="finalizar_compra.php?metodo=boleto" class="payment-card p-4 text-center">
                        <i class="bi bi-barcode text-boleto"></i>
                        <h4 class="fw-bold text-dark">Boleto</h4>
                        <p class="text-muted small">Aprovação em até 48 horas úteis.</p>
                    </a>
                </div>
            </div>

            <p class="text-center mt-5 text-muted small">
                <i class="bi bi-shield-lock-fill me-1"></i> Pagamento processado em ambiente seguro e criptografado.
            </p>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>