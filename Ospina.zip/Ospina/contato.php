<?php include_once("includes/menu.php"); ?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contato | Essência Pura</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root { --primary-green: #7ca982; }
        
        body {
            background-color: #f4f7f6;
            padding-top: 100px;
            font-family: 'Inter', sans-serif;
        }

        .contact-card {
            border: none;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 15px 35px rgba(0,0,0,0.05);
        }

        .info-sidebar {
            background-color: var(--primary-green);
            color: white;
            padding: 3rem;
        }

        .form-section {
            background-color: white;
            padding: 3rem;
        }

        .form-control {
            border-radius: 8px;
            padding: 12px;
            border: 1px solid #eee;
            background-color: #fcfcfc;
        }

        .form-control:focus {
            border-color: var(--primary-green);
            box-shadow: 0 0 0 0.25rem rgba(124, 169, 130, 0.1);
        }

        .btn-send {
            background-color: var(--primary-green);
            border: none;
            padding: 12px;
            font-weight: 600;
            border-radius: 8px;
            transition: all 0.3s;
        }

        .btn-send:hover {
            background-color: #6a926f;
            transform: translateY(-2px);
        }

        .icon-box {
            width: 45px;
            height: 45px;
            background: rgba(255,255,255,0.2);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
        }
    </style>
</head>
<body>

<div class="container mb-5">
    <div class="row contact-card g-0">
        <div class="col-lg-5 info-sidebar d-flex flex-column justify-content-between">
            <div>
                <h2 class="fw-bold mb-4">Vamos conversar?</h2>
                <p class="opacity-75 mb-5">Adoraríamos ouvir você. Nossa equipe está pronta para tirar dúvidas sobre nossas fragrâncias ou ajudar com seu pedido.</p>
                
                <div class="d-flex align-items-center mb-4">
                    <div class="icon-box"><i class="bi bi-geo-alt fs-5"></i></div>
                    <div>
                        <p class="small mb-0 opacity-75">Localização</p>
                        <p class="fw-medium mb-0">Sarandi, Paraná - Brasil</p>
                    </div>
                </div>

                <div class="d-flex align-items-center mb-4">
                    <div class="icon-box"><i class="bi bi-whatsapp fs-5"></i></div>
                    <div>
                        <p class="small mb-0 opacity-75">WhatsApp</p>
                        <p class="fw-medium mb-0">+55 (44) 99118-0048</p>
                    </div>
                </div>

                <div class="d-flex align-items-center mb-4">
                    <div class="icon-box"><i class="bi bi-envelope fs-5"></i></div>
                    <div>
                        <p class="small mb-0 opacity-75">E-mail</p>
                        <p class="fw-medium mb-0">contato@essenciapura.com</p>
                    </div>
                </div>
            </div>

            <div class="mt-5">
                <a href="#" class="text-white me-3 fs-4"><i class="bi bi-instagram"></i></a>
                <a href="#" class="text-white me-3 fs-4"><i class="bi bi-facebook"></i></a>
            </div>
        </div>

        <div class="col-lg-7 form-section">
            <?php
            if (isset($_GET['status'])) {
                if ($_GET['status'] == 'success') {
                    echo '<div class="alert alert-success border-0 shadow-sm mb-4" role="alert">
                            <i class="bi bi-check-circle me-2"></i> Mensagem enviada com sucesso!
                          </div>';
                } elseif ($_GET['status'] == 'error') {
                    echo '<div class="alert alert-danger border-0 shadow-sm mb-4" role="alert">
                            <i class="bi bi-exclamation-triangle me-2"></i> Erro ao enviar. Tente novamente.
                          </div>';
                }
            }
            ?>

            <form action="processa_contato.php" method="POST">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label small fw-bold text-secondary">Seu Nome</label>
                        <input type="text" class="form-control" name="nome" placeholder="Ex: João Silva" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold text-secondary">Seu E-mail</label>
                        <input type="email" class="form-control" name="email" placeholder="email@exemplo.com" required>
                    </div>
                    <div class="col-12">
                        <label class="form-label small fw-bold text-secondary">Assunto</label>
                        <input type="text" class="form-control" name="assunto" placeholder="Como podemos ajudar?" required>
                    </div>
                    <div class="col-12">
                        <label class="form-label small fw-bold text-secondary">Sua Mensagem</label>
                        <textarea class="form-control" name="mensagem" rows="5" placeholder="Escreva sua mensagem aqui..." required></textarea>
                    </div>
                    <div class="col-12 mt-4">
                        <button type="submit" class="btn btn-success btn-send w-100 text-white">
                            ENVIAR MENSAGEM <i class="bi bi-send ms-2"></i>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>