<?php
session_start();
include_once("produtos_data.php"); 
include_once("includes/menu.php"); 
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Essência Pura | Fragrâncias Exclusivas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --primary-green: #7ca982;
            --soft-gray: #f8f9fa;
        }

        body {
            background-color: #f4f4f4;
            padding-top: 70px; /* Ajuste para o menu fixo */
        }

        /* Banner Hero Moderno */
        .hero-banner {
            height: 80vh;
            background: linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.4)), url("img/banner.jpeg") no-repeat center center;
            background-size: cover;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            text-align: center;
            margin-bottom: 60px;
        }

        .hero-title {
            font-size: 3.5rem;
            font-weight: 800;
            text-shadow: 0 4px 15px rgba(0,0,0,0.3);
        }

        /* Cards de Produto Estilo E-commerce Premium */
        .card-produto {
            border: none;
            border-radius: 20px;
            transition: all 0.3s ease;
            background: #fff;
            overflow: hidden;
            height: 100%;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }

        .card-produto:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.1);
        }

        .card-produto img {
            height: 320px;
            object-fit: cover;
            transition: transform 0.5s ease;
        }

        .card-produto:hover img {
            transform: scale(1.05);
        }

        .btn-detalhes {
            background-color: var(--primary-green);
            border: none;
            color: white;
            font-weight: 600;
            border-radius: 10px;
        }

        .btn-detalhes:hover {
            background-color: #6a926f;
            color: white;
        }

        .welcome-alert {
            position: fixed;
            top: 90px;
            right: 20px;
            z-index: 1050;
            border: none;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            animation: slideIn 0.5s ease-out, fadeOut 1s ease-out 4s forwards;
        }

        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        @keyframes fadeOut {
            to { opacity: 0; visibility: hidden; }
        }
    </style>
</head>
<body>

<?php
if (isset($_SESSION['just_logged_in']) && $_SESSION['just_logged_in'] === true) {
    $user_name = isset($_SESSION['user_name']) ? htmlspecialchars($_SESSION['user_name']) : 'Visitante';
    echo '<div class="alert alert-success welcome-alert d-flex align-items-center" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            Bem-vindo de volta, ' . $user_name . '!
          </div>';
    unset($_SESSION['just_logged_in']);
}
?>

<section class="hero-banner">
    <div class="container">
        <h1 class="hero-title mb-4">A Essência da Natureza<br>em Você</h1>
        <p class="fs-5 mb-4">Descubra fragrâncias exclusivas feitas com pureza e paixão.</p>
        <a href="#produtos" class="btn btn-light btn-lg px-5 py-3 rounded-pill fw-bold shadow">Explorar Coleção</a>
    </div>
</section>

<div class="container">
    <section id="sobre" class="py-5">
        <div class="row align-items-center">
            <div class="col-md-6 mb-4 mb-md-0">
                <h2 class="fw-bold mb-4">Nossa Essência</h2>
                <p class="text-secondary lh-lg">Desde a nossa fundação, buscamos capturar a beleza e a complexidade da natureza em cada frasco. Nossos perfumes são criados com ingredientes sustentáveis e processos artesanais que garantem uma fixação inigualável.</p>
            </div>
            <div class="col-md-6 text-center">
                <video class="w-100 rounded-4 shadow" controls muted loop>
                    <source src="video/perfume.mp4" type="video/mp4">
                    Seu navegador não suporta a tag de vídeo.
                </video>
            </div>
        </div>
    </section>

    <section id="produtos" class="py-5">
        <div class="d-flex justify-content-between align-items-end mb-5">
            <div>
                <h6 class="text-uppercase text-success fw-bold mb-2">Coleção 2026</h6>
                <h2 class="fw-bold m-0">Produtos em Destaque</h2>
            </div>
            <a href="#" class="text-decoration-none text-success fw-bold">Ver todos <i class="bi bi-arrow-right"></i></a>
        </div>

        <div class="row g-4">
            <?php 
            $produtos_em_destaque = array_slice($produtos, 0, 18, true); 
            foreach($produtos_em_destaque as $id => $p): 
            ?>
            <div class="col-lg-4 col-md-6">
                <div class="card card-produto">
                    <img src="<?= $p['imagem'] ?>" class="card-img-top" alt="<?= $p['nome'] ?>">
                    <div class="card-body p-4 text-center">
                        <h5 class="fw-bold mb-2"><?= $p['nome'] ?></h5>
                        <p class="text-success fs-5 fw-bold mb-3">R$ <?= number_format($p['preco'], 2, ',', '.') ?></p>
                        
                        <div class="d-grid gap-2">
                            <a href="detalhes.php?id=<?= $id ?>" class="btn btn-detalhes py-2">
                                <i class="bi bi-eye me-2"></i>Ver Detalhes
                            </a>
                            <a href="carrinho.php?action=add&id=<?= $id ?>" class="btn btn-outline-dark py-2 rounded-3">
                                <i class="bi bi-cart-plus me-2"></i>Adicionar
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </section>
</div>

<footer class="bg-dark text-white pt-5 pb-4 mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-4 mb-4">
                <h5 class="fw-bold mb-3">Essência Pura</h5>
                <p class="small opacity-75">Onde cada fragrância conta uma história única. Elevando o conceito de perfumaria fina desde 2020.</p>
            </div>
            <div class="col-md-4 mb-4 text-md-center">
                <h5 class="fw-bold mb-3">Siga-nos</h5>
                <a href="https://www.instagram.com/_silvax_07" target="_blank" class="text-white fs-4"><i class="bi bi-instagram"></i></a>
            </div>
            <div class="col-md-4 mb-4 text-md-end">
                <h5 class="fw-bold mb-3">Contato</h5>
                <p class="small mb-1">contato@essenciapura.com</p>
                <p class="small">+55 (44) 99118-0048</p>
            </div>
        </div>
        <hr class="opacity-25">
        <p class="text-center small opacity-50 mb-0">© 2026 Essência Pura. Todos os direitos reservados.</p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>