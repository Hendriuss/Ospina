<?php
session_start();
include 'produtos_data.php';
include_once("includes/menu.php"); // Inclusão do menu padrão

if (!isset($_SESSION['carrinho'])) {
    $_SESSION['carrinho'] = [];
}

// Adicionar produto
if (isset($_GET['action']) && $_GET['action'] === 'add') {
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if (isset($produtos[$id])) {
        $_SESSION['carrinho'][] = $id;
    }
    header("Location: carrinho.php");
    exit;
}

// Remover produto
if (isset($_GET['action']) && $_GET['action'] === 'remove') {
    $index = intval($_GET['index']);
    if (isset($_SESSION['carrinho'][$index])) {
        unset($_SESSION['carrinho'][$index]);
        $_SESSION['carrinho'] = array_values($_SESSION['carrinho']);
    }
    header("Location: carrinho.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meu Carrinho | Essência Pura</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root { --primary-green: #7ca982; --dark-green: #5d8463; }
        
        body { 
            background-color: #f4f7f6; 
            padding-top: 100px; /* Espaço para o menu fixo */
            font-family: 'Inter', sans-serif;
        }

        .product-img { 
            width: 100px; 
            height: 100px; 
            object-fit: cover; 
            border-radius: 15px; 
            box-shadow: 0 4px 10px rgba(0,0,0,0.08);
        }

        .card-cart { 
            border: none; 
            border-radius: 20px; 
            background: white;
            box-shadow: 0 10px 30px rgba(0,0,0,0.05); 
        }

        .summary-card { 
            background-color: white; 
            border: none;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.05);
        }

        .btn-remove { 
            color: #ff6b6b; 
            font-size: 0.85rem;
            font-weight: 600;
            transition: 0.2s; 
        }
        
        .btn-remove:hover { 
            color: #fa5252; 
            text-decoration: underline !important;
        }

        .btn-checkout {
            background-color: var(--primary-green);
            border: none;
            border-radius: 12px;
            padding: 15px;
            font-weight: 700;
            transition: 0.3s;
        }

        .btn-checkout:hover {
            background-color: var(--dark-green);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(124, 169, 130, 0.3);
        }
    </style>
</head>
<body>

<div class="container mb-5">
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="fw-bold m-0">Meu Carrinho</h2>
                <span class="badge bg-white text-dark border rounded-pill px-3 py-2 shadow-sm">
                    <?= count($_SESSION['carrinho']) ?> itens
                </span>
            </div>

            <?php if (empty($_SESSION['carrinho'])): ?>
                <div class="card-cart p-5 text-center">
                    <i class="bi bi-bag-x display-1 text-muted opacity-25 mb-3"></i>
                    <h3 class="fw-bold">Seu carrinho está vazio</h3>
                    <p class="text-muted">Parece que você ainda não escolheu sua essência.</p>
                    <a href="index.php" class="btn btn-dark rounded-pill px-4 py-2 mt-2">Descobrir Fragrâncias</a>
                </div>
            <?php else: ?>
                <div class="card-cart p-4 mb-3">
                    <?php
                    $total = 0;
                    foreach ($_SESSION['carrinho'] as $index => $id_produto):
                        $produto = $produtos[$id_produto] ?? null;
                        if ($produto):
                            $total += $produto['preco'];
                    ?>
                    <div class="row align-items-center g-3 <?php echo $index > 0 ? 'border-top pt-4 mt-4' : ''; ?>">
                        <div class="col-auto">
                            <img src="<?= htmlspecialchars($produto['imagem']) ?>" class="product-img" alt="Produto">
                        </div>
                        <div class="col">
                            <h5 class="mb-1 fw-bold text-dark"><?= htmlspecialchars($produto['nome']) ?></h5>
                            <p class="small text-muted mb-2">Fragrância Premium • 100ml</p>
                            <a href="carrinho.php?action=remove&index=<?= $index ?>" class="btn-remove btn btn-link p-0 text-decoration-none">
                                <i class="bi bi-trash3 me-1"></i>Remover item
                            </a>
                        </div>
                        <div class="col-auto text-end">
                            <span class="fs-5 fw-bold d-block text-dark">R$ <?= number_format($produto['preco'], 2, ',', '.') ?></span>
                        </div>
                    </div>
                    <?php 
                        endif;
                    endforeach; 
                    ?>
                </div>
                
                <a href="index.php" class="btn btn-link text-decoration-none text-muted fw-medium p-0">
                    <i class="bi bi-arrow-left me-2"></i>Continuar Comprando
                </a>
            <?php endif; ?>
        </div>

        <?php if (!empty($_SESSION['carrinho'])): ?>
        <div class="col-lg-4">
            <div class="summary-card p-4 sticky-top" style="top: 110px;">
                <h4 class="fw-bold mb-4">Resumo do Pedido</h4>
                
                <div class="d-flex justify-content-between mb-3">
                    <span class="text-muted">Subtotal</span>
                    <span class="fw-medium">R$ <?= number_format($total, 2, ',', '.') ?></span>
                </div>
                
                <div class="d-flex justify-content-between mb-3 text-success small fw-bold">
                    <span>Frete</span>
                    <span>GRÁTIS</span>
                </div>
                
                <hr class="opacity-10">
                
                <div class="d-flex justify-content-between mb-4">
                    <span class="fs-5 fw-bold">Total</span>
                    <span class="fs-5 fw-bold text-dark">R$ <?= number_format($total, 2, ',', '.') ?></span>
                </div>

                <div class="alert alert-light border-0 small text-muted mb-4" style="background-color: #fbfbfb;">
                    <i class="bi bi-shield-check text-success me-2"></i> Compra segura com criptografia SSL.
                </div>

                <a href="pagamento.php" class="btn btn-success btn-checkout w-100 shadow-sm text-white">
                    FECHAR PEDIDO <i class="bi bi-arrow-right ms-2"></i>
                </a>

                <div class="text-center mt-4 opacity-50">
                    <p class="small mb-2">Aceitamos:</p>
                    <div class="d-flex justify-content-center gap-3 fs-3">
                        <i class="bi bi-credit-card"></i>
                        <i class="bi bi-qr-code"></i>
                        <i class="bi bi-bank"></i>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>