<?php
include_once("includes/conexao.php");
include_once("includes/classes/Usuario.php");

$db = new Database();
$usuario = new Usuario($db);

$nome  = filter_input(INPUT_POST, 'nome', FILTER_UNSAFE_RAW);
$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
$senha = filter_input(INPUT_POST, 'senha', FILTER_UNSAFE_RAW);

try {
    // Tenta realizar o cadastro
    if ($usuario->cadastrar($nome, $email, $senha)) {
        header('Location: login.php?cadastro_ok=true');
        exit();
    } else {
        // Caso o método retorne false por outro motivo
        header('Location: cadastro.php?error=falha_geral');
        exit();
    }
} catch (mysqli_sql_exception $e) {
    // Verifica se o erro é o 1062 (Duplicate Entry)
    if ($e->getCode() === 1062) {
        header('Location: cadastro.php?error=email_existente');
    } else {
        // Outro erro de banco de dados
        header('Location: cadastro.php?error=erro_banco');
    }
    exit();
} finally {
    $db->close();
}
?>