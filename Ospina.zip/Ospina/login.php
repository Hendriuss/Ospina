<?php
session_start();
include_once "includes/conexao.php"; 

$db = new Database(); 

if (isset($_SESSION['logado'])) {
    header("Location: index.php");
    exit();
}

$mensagem_erro = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login_padrao'])) {
    $login = trim($_POST['email']); 
    $senha = $_POST['senha'];

    $sql  = "SELECT id, nome, senha, nivel FROM usuarios WHERE login = ?";
    $stmt = $db->prepareAndExecute($sql, "s", $login); 
    $resultado = $stmt->get_result();

    if ($user = $resultado->fetch_assoc()) {
        if (password_verify($senha, $user['senha'])) {
            $_SESSION['logado'] = true;
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['nome'];
            $_SESSION['user_nivel'] = $user['nivel'];
            $_SESSION['just_logged_in'] = true;

            header("Location: index.php");
            exit();
        }
    }
    $mensagem_erro = "E-mail ou senha incorretos. Tente novamente.";
}
$db->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Essência Pura</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        :root { --primary-green: #7ca982; --dark-green: #5d8463; }

        body {
            background: url('img/fundo.jpg') no-repeat center center fixed; 
            background-size: cover; 
            display: flex;
            justify-content: flex-end; /* Card à direita */
            align-items: center; 
            min-height: 100vh;
            padding: 0 8%; /* Margem lateral no desktop */
            font-family: 'Inter', sans-serif;
        }

        /* Glassmorphism Effect */
        .login-container {
            width: 100%;
            max-width: 420px;
            padding: 50px 40px;
            border-radius: 24px;
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px); /* Desfoque do fundo */
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.3);
            text-align: center;
        }

        .header-logo {
            font-size: 2.2rem;
            font-weight: 800;
            color: var(--dark-green);
            margin-bottom: 10px;
            letter-spacing: -1px;
        }

        .form-label {
            font-weight: 600;
            font-size: 0.85rem;
            color: #555;
            margin-bottom: 8px;
        }

        .form-control {
            border-radius: 12px;
            padding: 12px 15px;
            border: 1px solid #ddd;
            background: rgba(255, 255, 255, 0.8);
            transition: all 0.3s;
        }

        .form-control:focus {
            border-color: var(--primary-green);
            box-shadow: 0 0 0 4px rgba(124, 169, 130, 0.15);
        }

        .btn-principal {
            background-color: var(--primary-green);
            border: none;
            border-radius: 12px;
            padding: 14px;
            font-weight: 700;
            color: white;
            transition: 0.3s;
        }

        .btn-principal:hover {
            background-color: var(--dark-green);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(93, 132, 99, 0.3);
        }

        .btn-google {
            background: white;
            border: 1px solid #ddd;
            border-radius: 12px;
            padding: 12px;
            font-weight: 600;
            color: #444;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            transition: 0.2s;
        }

        .btn-google:hover {
            background: #f8f9fa;
            border-color: #ccc;
        }

        .divider {
            display: flex;
            align-items: center;
            text-align: center;
            margin: 25px 0;
            color: #aaa;
            font-size: 0.8rem;
        }

        .divider::before, .divider::after {
            content: '';
            flex: 1;
            border-bottom: 1px solid #eee;
        }

        .divider:not(:empty)::before { margin-right: .5em; }
        .divider:not(:empty)::after { margin-left: .5em; }

        .extra-links a {
            text-decoration: none;
            color: var(--dark-green);
            font-weight: 600;
            transition: 0.2s;
        }

        .extra-links a:hover { color: var(--primary-green); }

        /* Erro flutuante */
        .alert-temporaria {
            position: fixed;
            top: 25px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 10000;
            border: none;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            animation: slideDown 0.5s ease-out, fadeOut 0.5s ease-in 3.5s forwards;
        }

        @keyframes slideDown { from { top: -50px; opacity: 0; } to { top: 25px; opacity: 1; } }
        @keyframes fadeOut { to { opacity: 0; visibility: hidden; } }

        @media (max-width: 768px) {
            body { justify-content: center; padding: 20px; }
        }
    </style>
</head>
<body>

<?php if ($mensagem_erro): ?>
    <div class="alert alert-danger alert-temporaria d-flex align-items-center" role="alert">
        <i class="bi bi-exclamation-circle-fill me-2"></i> <?= $mensagem_erro ?>
    </div>
<?php endif; ?>

<div class="login-container">
    <div class="header-logo">
        <i class="bi bi-droplet-half me-1"></i> Essência Pura
    </div>
    <p class="text-muted mb-4 small fw-medium">Sinta a fragrância da exclusividade</p>

    <form method="POST">
        <div class="mb-3 text-start">
            <label class="form-label">E-MAIL OU USUÁRIO</label>
            <input type="text" class="form-control" name="email" placeholder="Digite seu acesso" required>
        </div>
        <div class="mb-3 text-start text-end">
            <div class="d-flex justify-content-between">
                <label class="form-label">SENHA</label>
                <a href="esqueci_senha.php" class="small text-muted text-decoration-none">Esqueceu?</a>
            </div>
            <input type="password" class="form-control" name="senha" placeholder="••••••••" required>
        </div>

        <div class="d-grid mb-3 mt-4">
            <button type="submit" name="login_padrao" class="btn btn-principal">ENTRAR</button>
        </div>
    </form>

    <div class="divider">OU ACESSE COM</div>

    <div class="d-grid mb-4">
        <a href="login_google.php" class="btn btn-google">
            <img src="https://upload.wikimedia.org/wikipedia/commons/c/c1/Google_%22G%22_logo.svg" alt="Google" style="height:18px;">
            Google
        </a>
    </div>

    <div class="extra-links small">
        <span class="text-muted">Não tem uma conta?</span> 
        <a href="cadastro.php" class="ms-1">Cadastre-se</a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>