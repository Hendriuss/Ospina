<?php
session_start();
include_once "includes/conexao.php"; 

$mensagem_erro = "";
$token_valido = false;
$token = $_GET['token'] ?? ''; // Pega o token da URL

if (!empty($token)) {
    // 1. Verificar se o token existe e não expirou
    $agora = date("Y-m-d H:i:s");
    $sql_check = "SELECT user_id FROM password_resets WHERE token = ? AND expira_em > ?";
    $stmt_check = $conexao->prepare($sql_check);
    $stmt_check->bind_param("ss", $token, $agora);
    $stmt_check->execute();
    $resultado_check = $stmt_check->get_result();

    if ($reset_data = $resultado_check->fetch_assoc()) {
        $user_id = $reset_data['user_id'];
        $token_valido = true;
    } else {
        $mensagem_erro = "Token inválido ou expirado. Solicite uma nova redefinição.";
    }
} else {
    $mensagem_erro = "Token de redefinição não fornecido.";
}

// 2. Processar a redefinição da senha
if ($token_valido && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $nova_senha = $_POST['nova_senha'];
    $confirma_senha = $_POST['confirma_senha'];
    
    if ($nova_senha !== $confirma_senha) {
        $mensagem_erro = "As senhas não coincidem.";
    } elseif (strlen($nova_senha) < 6) { // Exemplo de validação
        $mensagem_erro = "A nova senha deve ter pelo menos 6 caracteres.";
    } else {
        // Criptografar a nova senha
        $senha_hash = password_hash($nova_senha, PASSWORD_DEFAULT);
        
        // Atualizar a senha do usuário
        $sql_update = "UPDATE usuarios SET senha = ? WHERE id = ?";
        $stmt_update = $conexao->prepare($sql_update);
        $stmt_update->bind_param("si", $senha_hash, $user_id);
        
        if ($stmt_update->execute()) {
            // 3. Apagar o token para que não possa ser usado novamente
            $sql_delete = "DELETE FROM password_resets WHERE user_id = ?";
            $stmt_delete = $conexao->prepare($sql_delete);
            $stmt_delete->bind_param("i", $user_id);
            $stmt_delete->execute();
            
            // Redirecionar para o login com mensagem de sucesso
            $_SESSION['mensagem_sucesso'] = "Sua senha foi redefinida com sucesso! Faça login.";
            header("Location: login.php");
            exit();
        } else {
            $mensagem_erro = "Erro ao redefinir a senha. Tente novamente.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
</head>
<body>
<div class="login-container">
    <div class="header-logo">
        <i class="bi bi-lock-open-fill me-2"></i> Nova Senha
    </div>

    <?php if ($mensagem_erro): ?>
        <div class="alert alert-danger alert-temporaria" style="animation: none; opacity: 1; position: static;">
            <?= $mensagem_erro ?>
        </div>
    <?php endif; ?>

    <?php if ($token_valido): ?>
        <h5 class="mb-4">Digite sua nova senha:</h5>
        <form method="POST">
            <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">
            
            <div class="mb-3 text-start">
                <label for="nova_senha" class="form-label">Nova Senha</label>
                <input type="password" class="form-control" id="nova_senha" name="nova_senha" required>
            </div>
            <div class="mb-3 text-start">
                <label for="confirma_senha" class="form-label">Confirmar Senha</label>
                <input type="password" class="form-control" id="confirma_senha" name="confirma_senha" required>
            </div>
            
            <div class="d-grid gap-2 mb-3">
                <button type="submit" class="btn btn-principal btn-lg">Redefinir Senha</button>
            </div>
        </form>
    <?php else: ?>
        <p class="mt-4">Por favor, volte para a tela de <a href="esqueci_senha.php">solicitação de redefinição</a> para gerar um novo link.</p>
    <?php endif; ?>
    
</div>
</body>
</html>