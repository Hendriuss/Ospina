<?php
session_start();
include 'produtos_data.php';
include_once("includes/menu.php");

$metodo_pagamento = $_GET['metodo'] ?? '';

if (empty($metodo_pagamento)) {
    header("Location: pagamento.php");
    exit;
}

if (empty($_SESSION['carrinho'])) {
    header("Location: carrinho.php");
    exit;
}

$total_carrinho = 0;
$itens_carrinho = [];
foreach ($_SESSION['carrinho'] as $id_produto) {
    if (isset($produtos[$id_produto])) {
        $itens_carrinho[] = $produtos[$id_produto];
        $total_carrinho += $produtos[$id_produto]['preco'];
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finalizar Compra | Essência Pura</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root { --primary-green: #7ca982; }
        body { background-color: #f4f7f6; font-family: 'Inter', sans-serif; }
        
        .card { border: none; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); }
        .form-control, .form-select { border-radius: 8px; padding: 12px; border: 1px solid #e0e0e0; }
        .form-control:focus { border-color: var(--primary-green); box-shadow: 0 0 0 0.25rem rgba(124, 169, 130, 0.15); }
        
        .order-summary { background: #fff; position: sticky; top: 20px; }
        .pix-box { background: #f8f9fa; border: 2px dashed #dee2e6; border-radius: 12px; padding: 20px; }
        .qr-code-wrapper { background: white; padding: 15px; display: inline-block; border-radius: 10px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); }
        
        .step-title { font-weight: 700; color: #2c3e50; margin-bottom: 20px; display: flex; align-items: center; }
        .step-title i { color: var(--primary-green); margin-right: 10px; }
        
        .total-highlight { font-size: 1.5rem; color: #2e7d32; font-weight: 800; }
    </style>
</head>
<body>

<div class="container my-5">
    <div class="text-center mb-5">
        <h2 class="fw-bold">Finalize seu Pedido</h2>
        <p class="text-muted">Quase lá! Complete as informações para garantir sua fragrância.</p>
    </div>

    <div class="row g-4">
        <div class="col-lg-4 order-lg-2">
            <div class="card order-summary p-4">
                <h5 class="fw-bold mb-3">Resumo do Pedido</h5>
                <div class="list-group list-group-flush mb-3">
                    <?php foreach ($itens_carrinho as $item): ?>
                    <div class="list-group-item d-flex justify-content-between align-items-center px-0 bg-transparent">
                        <div>
                            <h6 class="mb-0 small fw-bold"><?= htmlspecialchars($item['nome']) ?></h6>
                            <small class="text-muted">1 unidade</small>
                        </div>
                        <span class="text-dark small fw-medium text-nowrap">R$ <?= number_format($item['preco'], 2, ',', '.') ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>

                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">Subtotal</span>
                    <span class="fw-medium">R$ <?= number_format($total_carrinho, 2, ',', '.') ?></span>
                </div>
                <div class="d-flex justify-content-between mb-3 text-success">
                    <span>Frete</span>
                    <span class="fw-medium">Grátis</span>
                </div>
                <hr>
                <div class="d-flex justify-content-between align-items-center mb-0">
                    <span class="fw-bold">Total</span>
                    <span class="total-highlight">R$ <?= number_format($total_carrinho, 2, ',', '.') ?></span>
                </div>
            </div>
        </div>

        <div class="col-lg-8 order-lg-1">
            <div class="card p-4 mb-4">
                <h5 class="step-title"><i class="bi bi-geo-alt"></i> Dados de Entrega</h5>
                <form action="confirmacao.php" method="POST" class="needs-validation" novalidate>
                    <div class="row g-3">
                        <div class="col-sm-6">
                            <label class="form-label small fw-bold">Nome</label>
                            <input type="text" class="form-control" placeholder="Ex: João" required>
                        </div>
                        <div class="col-sm-6">
                            <label class="form-label small fw-bold">Sobrenome</label>
                            <input type="text" class="form-control" placeholder="Ex: Silva" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-bold">E-mail para rastreio</label>
                            <input type="email" class="form-control" placeholder="joao@email.com" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-bold">Endereço Completo</label>
                            <input type="text" class="form-control" placeholder="Rua, número e complemento" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Estado</label>
                            <select class="form-select" required>
                                <option value="">Selecione...</option>
                                <option>Paraná</option>
                                <option>São Paulo</option>
                                <option>Rio de Janeiro</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">CEP</label>
                            <input type="text" class="form-control" placeholder="00000-000" required>
                        </div>
                    </div>

                    <hr class="my-5">

                    <h5 class="step-title"><i class="bi bi-credit-card"></i> Pagamento: <?= ucfirst($metodo_pagamento) ?></h5>

                    <?php if ($metodo_pagamento === 'pix'): ?>
                        <div class="pix-box text-center">
                            <div class="qr-code-wrapper mb-3">
                                <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=ChavePixExemplo" alt="QR Code" class="img-fluid">
                            </div>
                            <p class="small text-muted mb-3">Escaneie o código acima ou copie a chave abaixo</p>
                            
                            <div class="input-group mb-2">
                                <input type="text" class="form-control text-center fw-bold bg-white" id="pix-key" value="44991180048" readonly>
                                <button class="btn btn-dark" type="button" onclick="copyPixKey()">
                                    <i class="bi bi-copy"></i> Copiar
                                </button>
                            </div>
                            <small class="text-success"><i class="bi bi-shield-check"></i> Pagamento processado instantaneamente.</small>
                        </div>

                    <?php elseif ($metodo_pagamento === 'cartao'): ?>
                        <div class="row gy-3">
                            <div class="col-12">
                                <label class="form-label small fw-bold">Número do Cartão</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-white"><i class="bi bi-credit-card-2-front"></i></span>
                                    <input type="text" class="form-control" placeholder="0000 0000 0000 0000" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Validade</label>
                                <input type="text" class="form-control" placeholder="MM/AA" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">CVV</label>
                                <input type="text" class="form-control" placeholder="123" required>
                            </div>
                        </div>

                    <?php elseif ($metodo_pagamento === 'boleto'): ?>
                        <div class="alert alert-light border d-flex align-items-center">
                            <i class="bi bi-info-circle fs-4 me-3 text-primary"></i>
                            <div>
                                <strong>Atenção:</strong> O boleto vence em 2 dias úteis. O prazo de entrega começa a contar após a compensação bancária.
                            </div>
                        </div>
                    <?php endif; ?>

                    <button class="btn btn-success btn-lg w-100 mt-5 py-3 fw-bold shadow" type="submit">
                        CONFIRMAR E FINALIZAR COMPRA
                    </button>
                    <p class="text-center mt-3 small text-muted">
                        <i class="bi bi-lock"></i> Ambiente 100% Seguro
                    </p>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function copyPixKey() {
        const pixKey = document.getElementById('pix-key');
        pixKey.select();
        document.execCommand("copy");
        alert('Chave Pix copiada com sucesso!');
    }

    // Script do Bootstrap para validar campos
    (function () {
      'use strict'
      var forms = document.querySelectorAll('.needs-validation')
      Array.prototype.slice.call(forms).forEach(function (form) {
        form.addEventListener('submit', function (event) {
          if (!form.checkValidity()) {
            event.preventDefault()
            event.stopPropagation()
          }
          form.classList.add('was-validated')
        }, false)
      })
    })()
</script>
</body>
</html>